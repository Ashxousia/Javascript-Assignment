function validateForm() {
    var x = document.forms["Ashler"]["Name"].value;
    if (x == null || x == "") {
        alert("Name must be filled out");
        return false;
    }

{
    var y = document.forms["Ashler"]["Surname"].value;
    if (y == null || y == "") {
        alert("Surname must be filled out");
        return false;
    }
}
{
    var a = document.forms["Ashler"]["Physical Adress"].value;
    if (a == null || a == "") {
        alert("Physical Address must be filled out");
        return false;
    }
}
{
    var b = document.forms["Ashler"]["Email Address"].value;
    if (b == null || b == "") {
        alert("Email Address must be filled out");
        return false;
    }
}
{
    var c = document.forms["Ashler"]["Telephone"].value;
    if (c == null || c == "") {
        alert("Telephone must be filled out");
        return false;
    }
}
{
    var d = document.forms["Ashler"]["Employee Number"].value;
    if (d== null || d == "") {
        alert("Employee Number must be filled out");
        return false;
    }
}
{
    var e = document.forms["Ashler"]["Username"].value;
    if (e == null || e == "") {
        alert("Username must be filled out");
        return false;
    }
}
{
    var f = document.forms["Ashler"]["Password"].value;
    if (f == null || f == "") {
        alert("Password must be filled out");
        return false;
    }
}
}